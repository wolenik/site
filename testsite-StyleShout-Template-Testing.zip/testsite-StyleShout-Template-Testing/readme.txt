SOURCES AND CREDITS:


Fonts:
 - Public Sans Font (https://fonts.google.com/specimen/Public+Sans)
 - DM Serif Display (https://fonts.google.com/specimen/DM+Serif+Display)

Icons:
 - Iconmonstr (https://iconmonstr.com/)

Stock Photos and Graphics:
 - Unsplash.com (https://unsplash.com/)
 
Javascript Files:
 - Anime.js (https://animejs.com/)
 - Swiper (https://swiperjs.com/)
 - MoveTo.js (https://github.com/hsnaydd/moveTo)
 - Prism.js (https://prismjs.com/)
 - Basic Lightbox (https://basiclightbox.electerious.com/)
 - MailtoUI (https://mailtoui.com/)

Images for qoutes:
 - Enstein: https://www.britannica.com/biography/Albert-Einstein
 - Confucius: https://www.worldhistory.org/Confucius/
 - Lau Tzu: https://www.viewbug.com/photo/85777542
 - Walt Whitman: https://poemanalysis.com/walt-whitman/biography/

